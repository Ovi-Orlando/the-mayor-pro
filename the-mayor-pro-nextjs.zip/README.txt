The Mayor Pro - Next.js edition (for Vercel)

Steps to deploy:
1) Push this folder to GitHub (repo the-mayor-pro).
2) In Vercel project settings, add environment variables:
   - GIST_ID = 2130bc7e621b0b1785d777180772092d
   - GITHUB_TOKEN = <your token with gist scope>
   - GIST_FILENAME = movies.json
3) Import the repo to Vercel and deploy.

Admin:
- Visit /admin?key=admin_ovi to manage entries.
